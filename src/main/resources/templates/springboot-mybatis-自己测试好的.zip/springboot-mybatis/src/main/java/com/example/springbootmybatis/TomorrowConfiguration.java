package com.example.springbootmybatis;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @Copyright (C), 2018-2021
 * @FileName: TomorrowConfiguration
 * @Author: Charles
 * @Date: 2021/1/20 22:37
 * @Description: 第21章并发 练习【】
 */
@ComponentScan("com.example.springbootmybatis.model")
@Configuration
public class TomorrowConfiguration {
}
